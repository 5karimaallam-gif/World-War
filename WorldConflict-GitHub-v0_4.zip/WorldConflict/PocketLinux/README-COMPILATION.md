# World Conflict 0.2 — compilation Debian ARM64 (Pocket Linux)

## Préparation initiale (une seule fois)
Dans Debian, décompresse l'archive, place-toi dans le dossier `WorldConflict`, puis lance :

```bash
bash PocketLinux/INSTALLER-DEBIAN.sh
```

Le script installe Java 17, télécharge le SDK Android ARM64 communautaire, puis installe Build Tools 35.0.2 et Android Platform 35. Il vérifie que `aapt2` fonctionne sur aarch64.

Le SDK ARM64 est fourni par `hamza72x/android-sdk-linux-arm64` (projet communautaire, pas une distribution officielle Google). Les exécutables sont annoncés comme compilés depuis les sources AOSP. Vérifie le dépôt et ses licences avant de l'utiliser si tu veux auditer les binaires.

## Compilation
Ouvre un nouveau terminal Debian, reviens dans le dossier `WorldConflict`, puis exécute :

```bash
bash PocketLinux/build.sh
```

APK : `app/build/outputs/apk/debug/app-debug.apk`

## À savoir
- Première installation et première compilation : connexion Internet obligatoire pour Java/SDK/Gradle/dépendances et le fichier cartographique Natural Earth.
- Le jeu installé fonctionne ensuite hors ligne, sans serveur, API, hébergement, compte ni clé.
- Prévois plusieurs Go d'espace libre. La compilation sur téléphone peut être lente et dépend de la mémoire disponible dans Pocket Linux.
- Le projet reste un prototype : seules les fonctions effectivement présentes dans le code sont disponibles ; sauvegardes et IA avancée restent à développer.
