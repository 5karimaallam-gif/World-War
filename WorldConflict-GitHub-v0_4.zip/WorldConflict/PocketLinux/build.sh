#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
GRADLE_VERSION="8.9"
CACHE="$HOME/.cache/world-conflict"
DIST="$CACHE/gradle-$GRADLE_VERSION"
ZIP="$CACHE/gradle-$GRADLE_VERSION-bin.zip"
[ "$(uname -m)" = "aarch64" ] || { echo "Ce script nécessite aarch64."; exit 1; }
if [ -z "${ANDROID_HOME:-}" ]; then
  if [ -d "$HOME/android-sdk" ]; then export ANDROID_HOME="$HOME/android-sdk"; else echo "Lance d'abord PocketLinux/INSTALLER-DEBIAN.sh"; exit 2; fi
fi
export ANDROID_SDK_ROOT="$ANDROID_HOME"
AAPT2="$ANDROID_HOME/build-tools/35.0.2/aapt2"
[ -x "$AAPT2" ] || { echo "AAPT2 ARM64 absent. Lance INSTALLER-DEBIAN.sh"; exit 3; }
file "$AAPT2"
"$AAPT2" version
mkdir -p "$CACHE"
if [ ! -x "$DIST/bin/gradle" ]; then
  echo "Téléchargement de Gradle $GRADLE_VERSION..."
  curl -fL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$ZIP"
  unzip -q -o "$ZIP" -d "$CACHE"
fi
printf 'sdk.dir=%s\n' "$ANDROID_HOME" > "$ROOT/local.properties"
echo "Compilation de World Conflict..."
"$DIST/bin/gradle" --no-daemon -p "$ROOT" \
  "-Pandroid.aapt2FromMavenOverride=$AAPT2" :app:assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
[ -f "$APK" ] || { echo "APK non trouvé après compilation."; exit 4; }
echo "APK créé : $APK"
