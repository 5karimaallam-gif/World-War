#!/usr/bin/env bash
set -euo pipefail

echo "=== World Conflict : préparation Debian ARM64 ==="
if [ "$(uname -m)" != "aarch64" ]; then
  echo "Erreur : prévu pour aarch64. Détecté : $(uname -m)"; exit 1
fi
if ! command -v apt-get >/dev/null 2>&1; then echo "apt-get introuvable : Debian requis."; exit 1; fi
if [ "$(id -u)" -eq 0 ]; then APT="apt-get"; elif command -v sudo >/dev/null 2>&1; then APT="sudo apt-get"; else echo "Droits administrateur requis pour installer Java 17."; exit 1; fi

echo "[1/4] Installation de Java 17 et utilitaires..."
$APT update
$APT install -y openjdk-17-jdk git curl wget unzip zip file python3 ca-certificates
java -version

SDK_TOOLS_DIR="$HOME/android-sdk-linux-arm64-tools"
ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
mkdir -p "$HOME"

echo "[2/4] Récupération du gestionnaire communautaire SDK ARM64..."
if [ ! -d "$SDK_TOOLS_DIR/.git" ]; then
  git clone --depth 1 https://github.com/hamza72x/android-sdk-linux-arm64.git "$SDK_TOOLS_DIR"
else
  git -C "$SDK_TOOLS_DIR" pull --ff-only
fi
export ANDROID_HOME ANDROID_SDK_ROOT="$ANDROID_HOME"

echo "[3/4] Installation des composants Android..."
"$SDK_TOOLS_DIR/setup.sh" install-build-tools 35.0.2
"$SDK_TOOLS_DIR/setup.sh" install-cmd-tools
"$SDK_TOOLS_DIR/setup.sh" install-platforms android-35

# Persist SDK paths for new Debian shells.
if ! grep -q 'ANDROID_HOME=.*android-sdk' "$HOME/.bashrc" 2>/dev/null; then
  printf '\nexport ANDROID_HOME="$HOME/android-sdk"\nexport ANDROID_SDK_ROOT="$ANDROID_HOME"\nexport PATH="$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"\n' >> "$HOME/.bashrc"
fi

echo "[4/4] Vérification AAPT2 ARM64..."
file "$ANDROID_HOME/build-tools/35.0.2/aapt2"
"$ANDROID_HOME/build-tools/35.0.2/aapt2" version

echo "\nPréparation terminée. Ouvre un nouveau terminal puis compile avec :"
echo "  cd CHEMIN/WorldConflict"
echo "  bash PocketLinux/build.sh"
echo "Note : premier téléchargement = Internet requis."
