# World Conflict 0.4 — simulateur de monde (style Ages of Conflict)

Vraie carte du monde en pixels (cases de 0,5°), vrais pays (Natural Earth, domaine public),
**un bot par nation**. Les frontières bougent au fil des guerres.

## Ce qui est simulé
- Chaque pays a de l'**or**, des **troupes**, une **économie** : tout est basé sur le vrai PIB et la vraie population.
- **Bots** : chaque nation décide seule de déclarer la guerre (surtout à un voisin plus faible), de mobiliser,
  de faire la paix, de former ou quitter une alliance.
- **Guerres** : uniquement entre pays voisins. Le front avance case par case, le plus fort gagne du terrain,
  les troupes s'usent. Les alliés peuvent rejoindre la guerre.
- **Alliances** : OTAN et OTSC au départ, d'autres se forment. Carte « Alliances » pour les voir.
- **Révoltes** : un territoire occupé peut retrouver sa nation d'origine. Une nation éliminée peut renaître.
- **Sauvegarde automatique** (reprise au relancement).

## Jouer
- ▶ lance la simulation, x1/x2/x4/x8 règle la vitesse. Pincer = zoom, glisser = déplacer, toucher = choisir un pays.
- **Observateur** : outils « Provoquer une guerre », « Imposer la paix », « Libérer les occupations ».
- **Contrôler ce pays** : déclarer la guerre à un voisin, proposer paix/alliance, mobiliser (coûte de l'or).
- Onglets : Nation / Monde (classement, alliances, guerres) / Journal.

## Compiler l'APK avec GitHub (gratuit)
1. Compte GitHub gratuit, nouveau dépôt.
2. Envoie **tout le contenu** de ce dossier à la racine du dépôt, **y compris le dossier caché `.github`**.
   Sinon : `Add file > Create new file`, nom `.github/workflows/build.yml`, colle `GITHUB-build.yml.txt`.
3. Onglet **Actions** → « Build APK » (ou Run workflow) → attendre 5 à 10 min.
4. Dans l'exécution terminée, **Artifacts** → télécharge `WorldConflict-debug-apk`, extrais, installe `app-debug.apk`.
