import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val worldMapFile = layout.projectDirectory.file("src/main/assets/countries.geojson")
val downloadWorldMap by tasks.registering {
    outputs.file(worldMapFile)
    doLast {
        val target = worldMapFile.asFile
        if (!target.exists() || target.length() < 50_000L) {
            target.parentFile.mkdirs()
            val source = URL("https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_110m_admin_0_countries.geojson")
            val temp = target.resolveSibling("countries.geojson.download")
            source.openStream().use { input -> temp.outputStream().use { input.copyTo(it) } }
            if (temp.length() < 50_000L) throw GradleException("La carte téléchargée semble incomplète.")
            if (!temp.renameTo(target)) throw GradleException("Impossible d'installer le fichier de carte.")
        }
    }
}
tasks.named("preBuild").configure { dependsOn(downloadWorldMap) }

android {
    namespace = "com.worldconflict.game"
    compileSdk = 35
    buildToolsVersion = "35.0.2"
    defaultConfig {
        applicationId = "com.worldconflict.game"
        minSdk = 23
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0"
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.03"))
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
