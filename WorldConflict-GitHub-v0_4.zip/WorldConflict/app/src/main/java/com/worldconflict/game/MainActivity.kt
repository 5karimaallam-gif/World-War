@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.worldconflict.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

private val bg = Color(0xFF0B1622)
private val panel = Color(0xFF1B2B40)
private val accent = Color(0xFFE2B866)
private val soft = Color(0xFFB7C5D6)

@Volatile
private var currentEngine: GameEngine? = null

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WorldConflictApp() }
    }

    override fun onPause() {
        super.onPause()
        currentEngine?.save(this)
    }
}

private fun fmtNum(v: Double): String = when {
    v >= 1e6 -> "%.1f M".format(v / 1e6)
    v >= 1e3 -> "%.1f k".format(v / 1e3)
    v >= 10 -> "%.0f".format(v)
    else -> "%.1f".format(v)
}

private fun fmtPop(m: Double): String = if (m >= 10) "%.0f M".format(m) else "%.2f M".format(m)

private fun fmtGdp(mUsd: Double): String = when {
    mUsd >= 1_000_000 -> "%.1f T\$".format(mUsd / 1_000_000)
    mUsd >= 1_000 -> "%.0f Md\$".format(mUsd / 1_000)
    else -> "%.0f M\$".format(mUsd)
}

@Composable
private fun WorldConflictApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var engine by remember { mutableStateOf<GameEngine?>(null) }
    var version by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }
    var speed by remember { mutableIntStateOf(2) }
    var tab by remember { mutableIntStateOf(0) }
    var confirmReset by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        try {
            val e = withContext(Dispatchers.Default) {
                val built = buildEngine(context)
                built.load(context)
                built
            }
            currentEngine = e
            engine = e
            version++
        } catch (t: Throwable) {
            error = "Impossible de charger la carte : ${t.message ?: "erreur"}"
        }
    }

    LaunchedEffect(engine, running, speed) {
        val eng = engine ?: return@LaunchedEffect
        var counter = 0
        try {
            while (running) {
                delay(100)
                for (k in 0 until speed) eng.step()
                eng.flush()
                version++
                counter++
                if (counter % 100 == 0) eng.save(context)
            }
        } finally {
            eng.save(context)
        }
    }

    val v = version
    val e = engine

    MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = bg, surface = panel)) {
        Column(Modifier.fillMaxSize().background(bg).padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("WORLD CONFLICT", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                    val sub = if (e == null) "Chargement du monde…" else {
                        val p = e.playerIdx
                        if (p >= 0) "Vous : ${e.nations[p].name} • Or ${fmtNum(e.nations[p].gold)} • Troupes ${fmtNum(e.nations[p].troops)}"
                        else "Mode observateur • ${e.aliveCount()} nations"
                    }
                    Text(sub, color = soft, fontSize = 11.sp)
                }
                if (e != null) {
                    Text(e.dateLabel(), color = accent, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Button(onClick = { running = !running }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) {
                        Text(if (running) "⏸" else "▶")
                    }
                    listOf(1, 2, 4, 8).forEach { s ->
                        TextButton(onClick = { speed = s }, contentPadding = PaddingValues(horizontal = 6.dp)) {
                            Text("x$s", color = if (speed == s) accent else Color.LightGray)
                        }
                    }
                    FilterChip(
                        selected = e.mapMode == 1,
                        onClick = { e.setMapMode(if (e.mapMode == 1) 0 else 1); e.flush(); version++ },
                        label = { Text("Alliances") }
                    )
                    TextButton(onClick = { confirmReset = true }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("↺", color = Color.LightGray) }
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.weight(3f).fillMaxHeight().background(bg, RoundedCornerShape(10.dp))) {
                    if (e == null) {
                        if (error != null) Text(error!!, color = Color.White, modifier = Modifier.align(Alignment.Center).padding(20.dp))
                        else CircularProgressIndicator(Modifier.align(Alignment.Center), color = accent)
                    } else {
                        WorldMap(e, v, { id -> e.select(id); e.flush(); version++ }, Modifier.fillMaxSize())
                    }
                }
                Column(Modifier.weight(1.25f).fillMaxHeight().background(panel, RoundedCornerShape(10.dp)).padding(8.dp)) {
                    if (e != null) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf("Nation", "Monde", "Journal").forEachIndexed { i, t ->
                                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(t, fontSize = 11.sp) })
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        when (tab) {
                            0 -> NationTab(e, v) { e.flush(); version++ }
                            1 -> WorldTab(e, v)
                            else -> LogTab(e, v)
                        }
                    }
                }
            }
        }
        if (confirmReset) {
            AlertDialog(
                onDismissRequest = { confirmReset = false },
                title = { Text("Nouveau monde ?") },
                text = { Text("La partie en cours sera effacée et le monde de 2026 sera rechargé.") },
                confirmButton = {
                    TextButton(onClick = {
                        confirmReset = false
                        running = false
                        scope.launch {
                            engine?.clearSave(context)
                            currentEngine = null
                            engine = null
                            val ne = withContext(Dispatchers.Default) { buildEngine(context) }
                            currentEngine = ne
                            engine = ne
                            version++
                        }
                    }) { Text("Recommencer") }
                },
                dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Annuler") } }
            )
        }
    }
}

@Composable
private fun NationTab(e: GameEngine, version: Int, changed: () -> Unit) {
    val sel = e.selected
    val p = e.playerIdx
    fun act(block: () -> Unit) { block(); changed() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        if (e.tick == 0L && sel < 0) {
            Text("Appuie sur ▶ pour lancer la simulation. Touche un pays, puis « Contrôler ce pays » pour le diriger, ou reste observateur : chaque nation est gérée par un bot.",
                color = soft, fontSize = 11.sp)
        }
        if (sel < 0) {
            Text("Touche un pays sur la carte.", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        } else {
            val s = e.nations[sel]
            Text(s.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            if (!s.alive) {
                Text("Nation éliminée.", color = Color.LightGray, fontSize = 11.sp)
            } else {
                Text("Territoire : ${s.cells} cases • Pop. ${fmtPop(s.pop)} • PIB ${fmtGdp(s.eco)}", color = Color.LightGray, fontSize = 11.sp)
                Text("Troupes ${fmtNum(s.troops)} / ${fmtNum(e.cap(s))} • Or ${fmtNum(s.gold)} (+${fmtNum(e.income(s))}/sem.)", color = Color.LightGray, fontSize = 11.sp)
                Text("Alliance : ${e.allianceName(sel) ?: "aucune"}", color = Color.LightGray, fontSize = 11.sp)
                val ws = e.warsOf(sel)
                Text("En guerre contre : ${if (ws.isEmpty()) "personne" else ws.joinToString(", ")}", color = if (ws.isEmpty()) Color.LightGray else Color(0xFFFF9A8A), fontSize = 11.sp)
                Spacer(Modifier.height(6.dp))
                if (p == sel) {
                    val cost = e.mobilizeCost(s)
                    Button(onClick = { act { e.mobilize(sel) } }, modifier = Modifier.fillMaxWidth(), enabled = s.gold >= cost) {
                        Text("Mobiliser • ${fmtNum(cost)} or", fontSize = 12.sp)
                    }
                    if (e.alliance[sel] >= 0) {
                        OutlinedButton(onClick = { act { e.leaveAlliance(sel) } }, modifier = Modifier.fillMaxWidth()) { Text("Quitter l'alliance", fontSize = 12.sp) }
                    }
                    OutlinedButton(onClick = { act { e.setPlayer(-1) } }, modifier = Modifier.fillMaxWidth()) { Text("Arrêter de contrôler", fontSize = 12.sp) }
                } else {
                    Button(onClick = { act { e.setPlayer(sel) } }, modifier = Modifier.fillMaxWidth()) { Text("Contrôler ce pays", fontSize = 12.sp) }
                    if (p >= 0) {
                        if (e.atWar(p, sel)) {
                            OutlinedButton(onClick = { act { e.proposePeace(p, sel) } }, modifier = Modifier.fillMaxWidth()) { Text("Proposer la paix", fontSize = 12.sp) }
                        } else {
                            OutlinedButton(onClick = { act { e.declareWar(p, sel) } }, modifier = Modifier.fillMaxWidth(), enabled = e.canDeclare(p, sel)) { Text("Déclarer la guerre", fontSize = 12.sp) }
                            val why = when {
                                e.sameAlliance(p, sel) -> "Vous êtes alliés."
                                !e.adjacent(p, sel) -> "Pas de frontière commune : guerre impossible."
                                e.truceLeft(p, sel) > 0 -> "Trêve en cours (${e.truceLeft(p, sel)} sem.)."
                                else -> null
                            }
                            if (why != null) Text(why, color = soft, fontSize = 10.sp)
                        }
                        if (e.sameAlliance(p, sel)) {
                            Text("Allié ✔", color = accent, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        } else {
                            OutlinedButton(
                                onClick = { act { e.proposeAlliance(p, sel) } },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !e.atWar(p, sel) && (e.alliance[p] < 0 || e.alliance[sel] < 0)
                            ) { Text("Proposer une alliance", fontSize = 12.sp) }
                        }
                    } else {
                        Text("OUTILS D'OBSERVATEUR", color = accent, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(top = 6.dp))
                        OutlinedButton(onClick = { act { e.forceWar(sel) } }, modifier = Modifier.fillMaxWidth()) { Text("Provoquer une guerre", fontSize = 12.sp) }
                        OutlinedButton(onClick = { act { e.forcePeace(sel) } }, modifier = Modifier.fillMaxWidth()) { Text("Imposer la paix", fontSize = 12.sp) }
                        OutlinedButton(onClick = { act { e.liberate(sel) } }, modifier = Modifier.fillMaxWidth()) { Text("Libérer les occupations", fontSize = 12.sp) }
                    }
                }
            }
        }
        val last = e.log.firstOrNull()
        if (last != null) {
            Spacer(Modifier.height(8.dp))
            Text(last, color = Color(0xFFD1DCE8), fontSize = 10.sp)
        }
    }
}

@Composable
private fun WorldTab(e: GameEngine, version: Int) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("CLASSEMENT (territoire)", color = accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        e.ranking(12).forEachIndexed { i, n ->
            Text("${i + 1}. ${n.name} — ${n.cells} cases • ${fmtNum(n.troops)} troupes", color = Color(0xFFD1DCE8), fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text("ALLIANCES", color = accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        val als = e.alliances.values.toList()
        if (als.isEmpty()) Text("Aucune alliance.", color = Color.LightGray, fontSize = 11.sp)
        als.forEach { a ->
            val members = e.nations.count { it.alive && e.alliance[it.idx] == a.id }
            Text("${a.name} — $members membres", color = Color(a.color), fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp))
        }
        Spacer(Modifier.height(8.dp))
        Text("GUERRES EN COURS : ${e.wars.size}", color = accent, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        e.wars.take(10).forEach { w ->
            Text("${e.nations[w.a].name} ⚔ ${e.nations[w.b].name}", color = Color(0xFFFF9A8A), fontSize = 11.sp, modifier = Modifier.padding(vertical = 1.dp))
        }
    }
}

@Composable
private fun LogTab(e: GameEngine, version: Int) {
    val lines = e.log.take(40)
    LazyColumn(Modifier.fillMaxSize()) {
        items(lines) { item -> Text(item, color = Color(0xFFD1DCE8), fontSize = 10.sp, modifier = Modifier.padding(vertical = 3.dp)) }
    }
}

@Composable
private fun WorldMap(engine: GameEngine, version: Int, onPick: (Int) -> Unit, modifier: Modifier = Modifier) {
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    val paint = remember {
        android.graphics.Paint().apply {
            isAntiAlias = true
            textAlign = android.graphics.Paint.Align.CENTER
            color = android.graphics.Color.WHITE
            isFakeBoldText = true
            setShadowLayer(4f, 0f, 0f, android.graphics.Color.BLACK)
        }
    }
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTransformGestures { centroid, delta, factor, _ ->
                    val s0 = min(size.width.toFloat() / GW, size.height.toFloat() / GH)
                    val newZoom = (zoom * factor).coerceIn(1f, 14f)
                    val f = newZoom / zoom
                    val cx = centroid.x - size.width / 2f
                    val cy = centroid.y - size.height / 2f
                    val maxX = max(0f, (GW * s0 * newZoom - size.width) / 2f)
                    val maxY = max(0f, (GH * s0 * newZoom - size.height) / 2f)
                    pan = Offset(
                        (cx * (1f - f) + pan.x * f + delta.x).coerceIn(-maxX, maxX),
                        (cy * (1f - f) + pan.y * f + delta.y).coerceIn(-maxY, maxY)
                    )
                    zoom = newZoom
                }
            }
            .pointerInput(engine) {
                detectTapGestures { tap ->
                    val s0 = min(size.width.toFloat() / GW, size.height.toFloat() / GH)
                    val scale = s0 * zoom
                    val fx = (tap.x - size.width / 2f - pan.x) / scale + GW / 2f
                    val fy = (tap.y - size.height / 2f - pan.y) / scale + GH / 2f
                    if (fx >= 0f && fy >= 0f && fx < GW && fy < GH) onPick(engine.owner[fy.toInt() * GW + fx.toInt()])
                    else onPick(-1)
                }
            }
    ) {
        if (version < 0) return@Canvas
        drawRect(bg)
        val s0 = min(size.width / GW, size.height / GH)
        val scale = s0 * zoom
        val dw = GW * scale
        val dh = GH * scale
        val left = size.width / 2f - dw / 2f + pan.x
        val top = size.height / 2f - dh / 2f + pan.y
        drawImage(
            image = engine.image,
            srcOffset = IntOffset.Zero,
            srcSize = IntSize(GW, GH),
            dstOffset = IntOffset(left.roundToInt(), top.roundToInt()),
            dstSize = IntSize(dw.roundToInt(), dh.roundToInt()),
            filterQuality = FilterQuality.None
        )
        drawIntoCanvas { canvas ->
            val nc = canvas.nativeCanvas
            for (n in engine.nations) {
                if (!n.alive || n.cells == 0) continue
                val span = sqrt(n.cells.toFloat()) * scale
                if (span < 30f) continue
                val px = left + (n.cx + 0.5f) * scale
                val py = top + (n.cy + 0.5f) * scale
                if (px < -50f || py < -50f || px > size.width + 50f || py > size.height + 50f) continue
                paint.textSize = min(span * 0.22f, 40f).coerceAtLeast(11f)
                val w = paint.measureText(n.name)
                if (w > span * 1.7f) paint.textSize = paint.textSize * span * 1.7f / w
                if (paint.textSize < 9f) continue
                nc.drawText(n.name, px, py, paint)
            }
        }
    }
}
