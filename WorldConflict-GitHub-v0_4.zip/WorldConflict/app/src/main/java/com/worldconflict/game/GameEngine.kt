package com.worldconflict.game

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.util.Base64
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import kotlin.math.floor
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

// Carte du monde en cases de 0,5° (720 x 360). Chaque case appartient à une nation.
const val GW = 720
const val GH = 360
const val CELL_DEG = 0.5

private const val PREFS = "worldconflict_v3"
private val OCEAN = AColor.rgb(19, 37, 58)
private val MONTHS = arrayOf("janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc.")

class Nation(
    val idx: Int, val name: String, val code: String, val color: Int,
    val basePop: Double, val baseGdp: Double, val aggression: Double
) {
    var cells = 0
    var eco = 0.0      // PIB cumulé du territoire contrôlé (millions de $)
    var pop = 0.0      // population du territoire contrôlé (millions)
    var cx = 0f
    var cy = 0f
    var gold = 0.0
    var troops = 0.0
    var alive = true
}

class War(val a: Int, val b: Int, val start: Long, val ta0: Double, val tb0: Double)
class Alliance(val id: Int, val name: String, val color: Int)

class GameEngine(
    val nations: List<Nation>,
    val owner: IntArray,
    val core: IntArray,
    private val ecoW: FloatArray,
    private val popW: FloatArray
) {
    private val N = nations.size
    val bitmap: Bitmap = Bitmap.createBitmap(GW, GH, Bitmap.Config.ARGB_8888)
    val image: ImageBitmap = bitmap.asImageBitmap()
    private val pix = IntArray(GW * GH)
    private val land: IntArray = owner.indices.filter { owner[it] >= 0 }.toIntArray()
    private val rnd = Random(System.nanoTime())

    var tick = 0L
    var playerIdx = -1
    var selected = -1
        private set
    var mapMode = 0
        private set
    val log = ArrayList<String>()
    val wars = ArrayList<War>()
    val alliance = IntArray(N) { -1 }
    val alliances = HashMap<Int, Alliance>()

    private val warFlag = BooleanArray(N * N)
    private val truceUntil = LongArray(N * N)
    private val adj = BooleanArray(N * N)
    private val warCount = IntArray(N)
    private var nextAllianceId = 0
    private var dirty = true
    private var quiet = false

    init {
        quiet = true
        scan()
        for (nat in nations) {
            nat.troops = cap(nat)
            nat.gold = income(nat) * 20.0
        }
        quiet = false
        recolorAll()
        flush()
    }

    // ------------------------------------------------------------ utilitaires

    fun dateLabel(): String = "${MONTHS[((tick % 52) * 12 / 52).toInt()]} ${2026 + tick / 52}"

    fun cap(nat: Nation): Double = max(1.0, nat.eco.pow(0.45) * (1.0 + nat.pop).pow(0.15))
    fun income(nat: Nation): Double = (nat.eco / 1e6).pow(0.7) + 0.02
    fun mobilizeCost(nat: Nation): Double = income(nat) * 10.0

    private fun addLog(msg: String) {
        if (quiet) return
        log.add(0, "${dateLabel()} — $msg")
        if (log.size > 80) log.removeAt(log.size - 1)
    }

    fun sameAlliance(a: Int, b: Int): Boolean = alliance[a] >= 0 && alliance[a] == alliance[b]
    fun atWar(a: Int, b: Int): Boolean = warFlag[a * N + b]
    fun adjacent(a: Int, b: Int): Boolean = adj[a * N + b]
    fun allianceName(i: Int): String? = alliances[alliance[i]]?.name
    fun truceLeft(a: Int, b: Int): Long = max(0L, truceUntil[a * N + b] - tick)

    fun warsOf(i: Int): List<String> = wars.filter { it.a == i || it.b == i }.map { nations[if (it.a == i) it.b else it.a].name }
    fun alliesOf(i: Int): List<String> =
        if (alliance[i] < 0) emptyList() else nations.filter { it.idx != i && it.alive && alliance[it.idx] == alliance[i] }.map { it.name }

    fun ranking(k: Int): List<Nation> = nations.filter { it.alive }.sortedByDescending { it.cells }.take(k)
    fun aliveCount(): Int = nations.count { it.alive }

    // ------------------------------------------------------------ couleurs / bitmap

    private fun shade(c: Int, f: Float) = AColor.rgb((AColor.red(c) * f).toInt(), (AColor.green(c) * f).toInt(), (AColor.blue(c) * f).toInt())
    private fun mix(c: Int, d: Int, t: Float) = AColor.rgb(
        (AColor.red(c) + (AColor.red(d) - AColor.red(c)) * t).toInt(),
        (AColor.green(c) + (AColor.green(d) - AColor.green(c)) * t).toInt(),
        (AColor.blue(c) + (AColor.blue(d) - AColor.blue(c)) * t).toInt()
    )

    private fun baseColor(o: Int): Int {
        if (mapMode == 1) {
            val al = alliance[o]
            return if (al >= 0) (alliances[al]?.color ?: AColor.rgb(85, 96, 107)) else AColor.rgb(74, 86, 99)
        }
        return nations[o].color
    }

    private fun colorAt(idx: Int): Int {
        val o = owner[idx]
        if (o < 0) return OCEAN
        var c = baseColor(o)
        val x = idx % GW
        val y = idx / GW
        val l = owner[if (x > 0) idx - 1 else idx + GW - 1]
        val r = owner[if (x + 1 < GW) idx + 1 else idx - GW + 1]
        val u = if (y > 0) owner[idx - GW] else -1
        val d = if (y + 1 < GH) owner[idx + GW] else -1
        val border = (l >= 0 && l != o) || (r >= 0 && r != o) || (u >= 0 && u != o) || (d >= 0 && d != o)
        if (o == selected) c = mix(c, AColor.WHITE, 0.35f)
        if (border) c = if (o == playerIdx) AColor.WHITE else shade(c, 0.7f)
        return c
    }

    private fun recolorAll() {
        for (i in pix.indices) pix[i] = colorAt(i)
        dirty = true
    }

    private fun refreshAround(idx: Int) {
        val x = idx % GW
        val y = idx / GW
        pix[idx] = colorAt(idx)
        pix[if (x > 0) idx - 1 else idx + GW - 1] = colorAt(if (x > 0) idx - 1 else idx + GW - 1)
        pix[if (x + 1 < GW) idx + 1 else idx - GW + 1] = colorAt(if (x + 1 < GW) idx + 1 else idx - GW + 1)
        if (y > 0) pix[idx - GW] = colorAt(idx - GW)
        if (y + 1 < GH) pix[idx + GW] = colorAt(idx + GW)
        dirty = true
    }

    fun flush() {
        if (dirty) {
            bitmap.setPixels(pix, 0, GW, 0, 0, GW, GH)
            dirty = false
        }
    }

    fun select(i: Int) {
        if (i == selected) return
        selected = i
        recolorAll()
    }

    fun setMapMode(m: Int) {
        mapMode = m
        recolorAll()
    }

    fun setPlayer(i: Int) {
        playerIdx = i
        recolorAll()
        if (i >= 0) addLog("Vous dirigez maintenant ${nations[i].name}.") else addLog("Vous êtes en mode observateur.")
    }

    // ------------------------------------------------------------ recensement du monde

    private fun scan() {
        val cnt = IntArray(N)
        val e = DoubleArray(N)
        val p = DoubleArray(N)
        val sx = DoubleArray(N)
        val sy = DoubleArray(N)
        java.util.Arrays.fill(adj, false)
        for (y in 0 until GH) {
            val row = y * GW
            for (x in 0 until GW) {
                val idx = row + x
                val o = owner[idx]
                if (o < 0) continue
                cnt[o]++
                e[o] += ecoW[idx].toDouble()
                p[o] += popW[idx].toDouble()
                sx[o] += x.toDouble()
                sy[o] += y.toDouble()
                val r = owner[if (x + 1 < GW) idx + 1 else row]
                if (r >= 0 && r != o) { adj[o * N + r] = true; adj[r * N + o] = true }
                if (y + 1 < GH) {
                    val d = owner[idx + GW]
                    if (d >= 0 && d != o) { adj[o * N + d] = true; adj[d * N + o] = true }
                }
            }
        }
        for (nat in nations) {
            val i = nat.idx
            nat.cells = cnt[i]
            nat.eco = e[i]
            nat.pop = p[i]
            if (cnt[i] > 0) { nat.cx = (sx[i] / cnt[i]).toFloat(); nat.cy = (sy[i] / cnt[i]).toFloat() }
            if (cnt[i] == 0 && nat.alive) {
                nat.alive = false
                nat.troops = 0.0
                onDeath(i)
            } else if (cnt[i] > 0 && !nat.alive) {
                nat.alive = true
                nat.troops = cap(nat) * 0.5
                addLog("${nat.name} renaît de ses cendres.")
            }
        }
        // Alliances de moins de deux membres : dissoutes
        val members = HashMap<Int, Int>()
        for (i in 0 until N) if (alliance[i] >= 0 && nations[i].alive) members[alliance[i]] = (members[alliance[i]] ?: 0) + 1
        for (i in 0 until N) {
            val al = alliance[i]
            if (al >= 0 && (members[al] ?: 0) < 2) alliance[i] = -1
        }
        alliances.keys.retainAll(alliance.filter { it >= 0 }.toSet())
    }

    private fun onDeath(i: Int) {
        for (w in ArrayList(wars)) if (w.a == i || w.b == i) makePeace(w.a, w.b, true)
        alliance[i] = -1
        addLog("${nations[i].name} a été rayé de la carte.")
        if (playerIdx == i) {
            playerIdx = -1
            addLog("Votre nation a été éliminée. Choisissez un autre pays ou observez.")
        }
    }

    // ------------------------------------------------------------ guerre et paix

    fun canDeclare(a: Int, b: Int): Boolean =
        a != b && nations[a].alive && nations[b].alive && !warFlag[a * N + b] && !sameAlliance(a, b) &&
            truceUntil[a * N + b] <= tick && adj[a * N + b]

    private fun startWar(a: Int, b: Int) {
        warFlag[a * N + b] = true
        warFlag[b * N + a] = true
        wars.add(War(a, b, tick, nations[a].troops, nations[b].troops))
        warCount[a]++
        warCount[b]++
    }

    fun declareWar(a: Int, b: Int): Boolean {
        if (!canDeclare(a, b)) return false
        startWar(a, b)
        addLog("${nations[a].name} déclare la guerre à ${nations[b].name}.")
        joinAllies(a, b)
        joinAllies(b, a)
        return true
    }

    private fun joinAllies(x: Int, enemy: Int) {
        val al = alliance[x]
        if (al < 0) return
        for (m in 0 until N) {
            if (m == x || m == enemy || alliance[m] != al || !nations[m].alive) continue
            if (warFlag[m * N + enemy] || sameAlliance(m, enemy) || warCount[m] >= 3) continue
            if (rnd.nextDouble() < 0.6) {
                startWar(m, enemy)
                addLog("${nations[m].name} entre en guerre contre ${nations[enemy].name} (alliance).")
            }
        }
    }

    fun makePeace(a: Int, b: Int, silent: Boolean = false) {
        if (!warFlag[a * N + b]) return
        warFlag[a * N + b] = false
        warFlag[b * N + a] = false
        wars.removeAll { (it.a == a && it.b == b) || (it.a == b && it.b == a) }
        warCount[a] = max(0, warCount[a] - 1)
        warCount[b] = max(0, warCount[b] - 1)
        truceUntil[a * N + b] = tick + 156
        truceUntil[b * N + a] = tick + 156
        if (!silent) addLog("Paix signée entre ${nations[a].name} et ${nations[b].name}.")
    }

    // ------------------------------------------------------------ alliances

    private fun allianceSize(al: Int): Int = (0 until N).count { alliance[it] == al && nations[it].alive }

    private fun canJoin(x: Int, al: Int): Boolean {
        if (allianceSize(al) >= 10) return false
        for (m in 0 until N) if (alliance[m] == al && warFlag[x * N + m]) return false
        return true
    }

    private fun allianceColor(id: Int): Int =
        AColor.HSVToColor(floatArrayOf(((id * 137.5f) % 360f), 0.6f, 0.9f))

    private fun formAlliance(a: Int, b: Int, name: String? = null): Boolean {
        if (alliance[a] >= 0 && alliance[b] >= 0) return false
        if (alliance[b] >= 0) {
            if (!canJoin(a, alliance[b])) return false
            alliance[a] = alliance[b]
            addLog("${nations[a].name} rejoint ${allianceName(a)}.")
        } else if (alliance[a] >= 0) {
            if (!canJoin(b, alliance[a])) return false
            alliance[b] = alliance[a]
            addLog("${nations[b].name} rejoint ${allianceName(b)}.")
        } else {
            if (warFlag[a * N + b]) return false
            val id = nextAllianceId++
            val nm = name ?: "Pacte ${nations[a].name}"
            alliances[id] = Alliance(id, nm, allianceColor(id))
            alliance[a] = id
            alliance[b] = id
            addLog("${nations[a].name} et ${nations[b].name} forment l'alliance « $nm ».")
        }
        return true
    }

    fun proposeAlliance(p: Int, other: Int): Boolean {
        if (!nations[other].alive || warFlag[p * N + other] || sameAlliance(p, other)) return false
        val chance = 0.35 + (if (adj[p * N + other]) 0.2 else 0.0)
        if (rnd.nextDouble() < chance && formAlliance(p, other)) return true
        addLog("${nations[other].name} décline l'alliance.")
        return false
    }

    fun leaveAlliance(x: Int) {
        if (alliance[x] < 0) return
        addLog("${nations[x].name} quitte ${allianceName(x)}.")
        alliance[x] = -1
    }

    fun proposePeace(p: Int, other: Int): Boolean {
        val w = wars.firstOrNull { (it.a == p && it.b == other) || (it.a == other && it.b == p) } ?: return false
        val dur = tick - w.start
        val o = nations[other]
        val start0 = if (w.a == other) w.ta0 else w.tb0
        val ro = o.troops / max(1.0, start0)
        var chance = 0.30 + (1.0 - ro).coerceIn(0.0, 0.5)
        if (dur < 8) chance = 0.1
        if (nations[p].troops > o.troops * 1.5) chance += 0.2
        if (rnd.nextDouble() < chance) { makePeace(p, other); return true }
        addLog("${o.name} refuse la paix.")
        return false
    }

    fun mobilize(i: Int): Boolean {
        val nat = nations[i]
        val cost = mobilizeCost(nat)
        if (!nat.alive || nat.gold < cost) return false
        nat.gold -= cost
        nat.troops = min(cap(nat) * 1.5, nat.troops + cap(nat) * 0.25)
        return true
    }

    // ------------------------------------------------------------ outils d'observateur

    fun forceWar(x: Int): Boolean {
        val cands = (0 until N).filter { canDeclare(x, it) }
        if (cands.isEmpty()) return false
        return declareWar(x, cands[rnd.nextInt(cands.size)])
    }

    fun forcePeace(x: Int) {
        for (w in ArrayList(wars)) if (w.a == x || w.b == x) makePeace(w.a, w.b)
    }

    fun liberate(x: Int) {
        var count = 0
        for (idx in land) {
            if (owner[idx] == x && core[idx] != x) { owner[idx] = core[idx]; count++ }
        }
        if (count > 0) {
            addLog("${nations[x].name} perd $count territoires occupés qui retrouvent leur nation d'origine.")
            scan()
            recolorAll()
        }
    }

    // ------------------------------------------------------------ simulation

    fun step() {
        tick++
        if (tick % 4L == 0L) scan()
        for (nat in nations) {
            if (!nat.alive) continue
            nat.gold += income(nat)
            val cp = cap(nat)
            nat.troops += (cp - nat.troops) * (if (nat.troops < cp) 0.012 else 0.01)
        }
        warStep()
        warUpdate()
        revolts()
        for (nat in nations) {
            if (nat.alive && nat.idx != playerIdx && (tick + nat.idx) % 6L == 0L) botAct(nat)
        }
    }

    /** Nombre de voisins directs (sur 4) appartenant à `who`. */
    private fun neighborCount(idx: Int, who: Int): Int {
        val x = idx % GW
        val y = idx / GW
        var k = 0
        if (owner[if (x > 0) idx - 1 else idx + GW - 1] == who) k++
        if (owner[if (x + 1 < GW) idx + 1 else idx - GW + 1] == who) k++
        if (y > 0 && owner[idx - GW] == who) k++
        if (y + 1 < GH && owner[idx + GW] == who) k++
        return k
    }

    /** Front de guerre : on échantillonne des cases au hasard et celles en bordure d'un ennemi peuvent changer de main. */
    private fun warStep() {
        if (wars.isEmpty()) return
        for (s in 0 until 20000) {
            val idx = land[rnd.nextInt(land.size)]
            val o = owner[idx]
            val x = idx % GW
            val y = idx / GW
            val idx2 = when (rnd.nextInt(4)) {
                0 -> if (x + 1 < GW) idx + 1 else idx - GW + 1
                1 -> if (x > 0) idx - 1 else idx + GW - 1
                2 -> if (y + 1 < GH) idx + GW else -1
                else -> if (y > 0) idx - GW else -1
            }
            if (idx2 < 0) continue
            val p = owner[idx2]
            if (p < 0 || p == o || !warFlag[o * N + p]) continue
            val att = nations[p].troops
            val def = nations[o].troops * 1.15
            val q = att / (att + def + 1e-9)
            val k = neighborCount(idx, p)
            if (rnd.nextFloat() < 0.3f * k * q.toFloat() * q.toFloat()) {
                owner[idx] = p
                nations[o].troops *= 0.9988
                nations[p].troops *= 0.9996
                refreshAround(idx)
            }
        }
    }

    private fun warUpdate() {
        for (i in wars.indices.reversed()) {
            if (i >= wars.size) continue
            val w = wars[i]
            val na = nations[w.a]
            val nb = nations[w.b]
            if (!na.alive || !nb.alive) { makePeace(w.a, w.b, true); continue }
            if (w.a == playerIdx || w.b == playerIdx) continue
            val dur = tick - w.start
            if (dur < 12) continue
            val ra = na.troops / max(1.0, w.ta0)
            val rb = nb.troops / max(1.0, w.tb0)
            var p = 0.004 + min(0.02, dur / 6000.0)
            if (min(ra, rb) < 0.45) p += 0.04
            if (rnd.nextDouble() < p) makePeace(w.a, w.b)
        }
    }

    /** Soulèvements : un territoire occupé peut retrouver sa nation d'origine. */
    private fun revolts() {
        for (s in 0 until 300) {
            val idx = land[rnd.nextInt(land.size)]
            val o = owner[idx]
            val c = core[idx]
            if (o == c || warFlag[o * N + c]) continue
            val k = neighborCount(idx, c)
            if (k == 0 && nations[c].alive) continue
            if (rnd.nextFloat() < 0.10f * max(1, k)) {
                owner[idx] = c
                refreshAround(idx)
            }
        }
    }

    private fun botAct(nat: Nation) {
        val i = nat.idx
        if (warCount[i] > 0 && nat.gold >= mobilizeCost(nat) && nat.troops < cap(nat) * 1.1) mobilize(i)

        if (alliance[i] < 0 && rnd.nextDouble() < 0.05) {
            val cands = (0 until N).filter { m ->
                m != i && adj[i * N + m] && nations[m].alive && !warFlag[i * N + m] &&
                    (alliance[m] < 0 || canJoin(i, alliance[m]))
            }
            if (cands.isNotEmpty()) formAlliance(i, cands[rnd.nextInt(cands.size)])
        } else if (alliance[i] >= 0 && rnd.nextDouble() < 0.002) {
            leaveAlliance(i)
        }

        if (tick > 26 && warCount[i] < 2 && rnd.nextDouble() < 0.010 * nat.aggression) {
            var best = -1
            var bestRatio = 0.0
            for (m in 0 until N) {
                if (!canDeclare(i, m)) continue
                val ratio = nat.troops / max(0.5, nations[m].troops)
                if (ratio > bestRatio) { bestRatio = ratio; best = m }
            }
            if (best >= 0 && (bestRatio > 1.4 || rnd.nextDouble() < 0.03)) declareWar(i, best)
        }
    }

    // ------------------------------------------------------------ sauvegarde

    private fun gz64(bytes: ByteArray): String {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(bytes) }
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    private fun ungz64(text: String): ByteArray =
        GZIPInputStream(ByteArrayInputStream(Base64.decode(text, Base64.NO_WRAP))).use { it.readBytes() }

    fun save(context: Context) {
        try {
            if (N > 254) return
            val root = JSONObject()
            root.put("n", N)
            root.put("tick", tick)
            root.put("player", playerIdx)
            root.put("map", mapMode)
            root.put("next", nextAllianceId)
            val bytes = ByteArray(GW * GH) { if (owner[it] < 0) (-1).toByte() else owner[it].toByte() }
            root.put("owner", gz64(bytes))
            val nat = JSONArray()
            for (x in nations) nat.put(JSONArray().put(x.code).put(x.gold).put(x.troops).put(alliance[x.idx]))
            root.put("nat", nat)
            val ws = JSONArray()
            for (w in wars) ws.put(JSONArray().put(w.a).put(w.b).put(w.start).put(w.ta0).put(w.tb0))
            root.put("wars", ws)
            val al = JSONArray()
            for (a in alliances.values) al.put(JSONArray().put(a.id).put(a.name).put(a.color))
            root.put("alliances", al)
            root.put("log", JSONArray(log.take(40)))
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("save", root.toString()).apply()
        } catch (_: Exception) { }
    }

    fun clearSave(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("save").apply()
    }

    fun load(context: Context): Boolean {
        try {
            val text = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("save", null) ?: return false
            val root = JSONObject(text)
            if (root.getInt("n") != N) return false
            val bytes = ungz64(root.getString("owner"))
            if (bytes.size != GW * GH) return false
            val natArr = root.getJSONArray("nat")
            if (natArr.length() != N) return false
            for (i in 0 until N) if (natArr.getJSONArray(i).getString(0) != nations[i].code) return false
            for (i in bytes.indices) {
                val b = bytes[i].toInt() and 0xFF
                if ((b == 255) != (owner[i] < 0)) return false
            }
            quiet = true
            for (i in bytes.indices) {
                val b = bytes[i].toInt() and 0xFF
                owner[i] = if (b == 255) -1 else b
            }
            java.util.Arrays.fill(warFlag, false)
            java.util.Arrays.fill(truceUntil, 0L)
            java.util.Arrays.fill(warCount, 0)
            wars.clear()
            alliances.clear()
            tick = root.getLong("tick")
            playerIdx = root.getInt("player")
            mapMode = root.getInt("map")
            nextAllianceId = root.getInt("next")
            val alArr = root.getJSONArray("alliances")
            for (k in 0 until alArr.length()) {
                val e = alArr.getJSONArray(k)
                alliances[e.getInt(0)] = Alliance(e.getInt(0), e.getString(1), e.getInt(2))
            }
            for (i in 0 until N) {
                val e = natArr.getJSONArray(i)
                nations[i].gold = e.getDouble(1)
                nations[i].troops = e.getDouble(2)
                alliance[i] = e.getInt(3)
                nations[i].alive = true
            }
            val wsArr = root.getJSONArray("wars")
            for (k in 0 until wsArr.length()) {
                val e = wsArr.getJSONArray(k)
                val a = e.getInt(0)
                val b = e.getInt(1)
                warFlag[a * N + b] = true
                warFlag[b * N + a] = true
                wars.add(War(a, b, e.getLong(2), e.getDouble(3), e.getDouble(4)))
                warCount[a]++
                warCount[b]++
            }
            val savedTroops = DoubleArray(N) { nations[it].troops }
            scan()
            for (i in 0 until N) if (!nations[i].alive) nations[i].troops = savedTroops[i]
            quiet = false
            val logArr = root.getJSONArray("log")
            log.clear()
            for (k in 0 until logArr.length()) log.add(logArr.getString(k))
            selected = -1
            recolorAll()
            flush()
            return true
        } catch (e: Exception) {
            quiet = false
            return false
        }
    }

    // ------------------------------------------------------------ départ : alliances réelles 2026

    fun presetAlliances() {
        quiet = true
        val byCode = HashMap<String, Int>()
        for (nat in nations) byCode[nat.code] = nat.idx
        val presets = listOf(
            "OTAN" to "USA CAN GBR FRA DEU ITA ESP PRT NLD BEL LUX DNK NOR ISL POL CZE SVK HUN ROU BGR GRC TUR EST LVA LTU HRV SVN ALB MKD MNE FIN SWE",
            "OTSC" to "RUS BLR ARM KAZ KGZ TJK"
        )
        for ((name, codes) in presets) {
            val id = nextAllianceId++
            alliances[id] = Alliance(id, name, allianceColor(id))
            for (c in codes.split(" ")) byCode[c]?.let { alliance[it] = id }
        }
        quiet = false
        recolorAll()
    }
}

// ================================================================ construction du monde

private class GeoPoint(val lon: Double, val lat: Double)
private class RawCountry(val name: String, val code: String, val rings: List<List<GeoPoint>>, val pop: Double, val gdp: Double) {
    val minLon = rings.minOf { r -> r.minOf { it.lon } }
    val maxLon = rings.maxOf { r -> r.maxOf { it.lon } }
    val minLat = rings.minOf { r -> r.minOf { it.lat } }
    val maxLat = rings.maxOf { r -> r.maxOf { it.lat } }
    val bboxArea = (maxLon - minLon) * (maxLat - minLat)
}

private fun readRing(arr: JSONArray): List<GeoPoint> {
    val pts = ArrayList<GeoPoint>(arr.length())
    for (j in 0 until arr.length()) {
        val xy = arr.getJSONArray(j)
        pts.add(GeoPoint(xy.getDouble(0), xy.getDouble(1)))
    }
    return pts
}

private fun fillRing(grid: IntArray, ring: List<GeoPoint>, value: Int, xs: DoubleArray) {
    if (ring.size < 3) return
    var minLat = 90.0
    var maxLat = -90.0
    for (p in ring) { minLat = min(minLat, p.lat); maxLat = max(maxLat, p.lat) }
    val yStart = max(0, ceil((90.0 - maxLat) / CELL_DEG - 0.5).toInt())
    val yEnd = min(GH - 1, floor((90.0 - minLat) / CELL_DEG - 0.5).toInt())
    for (y in yStart..yEnd) {
        val ly = 90.0 - (y + 0.5) * CELL_DEG
        var count = 0
        var j = ring.size - 1
        for (i in ring.indices) {
            val a = ring[j]
            val b = ring[i]
            if ((a.lat <= ly) != (b.lat <= ly) && count < xs.size) {
                xs[count++] = a.lon + (ly - a.lat) * (b.lon - a.lon) / (b.lat - a.lat)
            }
            j = i
        }
        java.util.Arrays.sort(xs, 0, count)
        var k = 0
        while (k + 1 < count) {
            val x1 = max(0, ceil((xs[k] + 180.0) / CELL_DEG - 0.5).toInt())
            val x2 = min(GW - 1, floor((xs[k + 1] + 180.0) / CELL_DEG - 0.5).toInt())
            for (x in x1..x2) grid[y * GW + x] = value
            k += 2
        }
    }
}

fun buildEngine(context: Context): GameEngine {
    val json = JSONObject(context.assets.open("countries.geojson").bufferedReader().use { it.readText() })
    val features = json.getJSONArray("features")
    val raws = ArrayList<RawCountry>()
    val used = HashSet<String>()
    for (i in 0 until features.length()) {
        val f = features.getJSONObject(i)
        val props = f.getJSONObject("properties")
        val fr = props.optString("NAME_FR", "")
        val name = if (fr.isNotBlank()) fr else props.optString("ADMIN", props.optString("name", "Territoire ${i + 1}"))
        var code = props.optString("ADM0_A3", "T$i")
        if (code == "ATA") continue // l'Antarctique n'est pas une nation
        if (code.isBlank() || code == "-99" || !used.add(code)) { code = "T$i"; used.add(code) }
        val geometry = f.getJSONObject("geometry")
        val rings = mutableListOf<List<GeoPoint>>()
        when (geometry.getString("type")) {
            "Polygon" -> {
                val rs = geometry.getJSONArray("coordinates")
                if (rs.length() > 0) rings.add(readRing(rs.getJSONArray(0)))
            }
            "MultiPolygon" -> {
                val polys = geometry.getJSONArray("coordinates")
                for (p in 0 until polys.length()) {
                    val rs = polys.getJSONArray(p)
                    if (rs.length() > 0) rings.add(readRing(rs.getJSONArray(0)))
                }
            }
        }
        if (rings.isEmpty()) continue
        val pop = props.optDouble("POP_EST", Double.NaN)
        val gdp = props.optDouble("GDP_MD", Double.NaN)
        raws.add(
            RawCountry(
                name, code, rings,
                if (pop.isNaN() || pop <= 0) 1_000_000.0 else pop,
                if (gdp.isNaN() || gdp <= 0) 20_000.0 else gdp
            )
        )
    }

    // Rasterisation : les grands pays d'abord, les petits par-dessus (enclaves comme le Lesotho)
    val grid = IntArray(GW * GH) { -1 }
    val xs = DoubleArray(4096)
    for (ci in raws.indices.sortedByDescending { raws[it].bboxArea }) {
        for (ring in raws[ci].rings) fillRing(grid, ring, ci, xs)
    }
    // Chaque pays garde au moins une case
    var counts = IntArray(raws.size)
    for (v in grid) if (v >= 0) counts[v]++
    for (ci in raws.indices) {
        if (counts[ci] == 0) {
            val pts = raws[ci].rings.flatten()
            val lon = pts.map { it.lon }.average()
            val lat = pts.map { it.lat }.average()
            val x = ((lon + 180.0) / CELL_DEG).toInt().coerceIn(0, GW - 1)
            val y = ((90.0 - lat) / CELL_DEG).toInt().coerceIn(0, GH - 1)
            grid[y * GW + x] = ci
        }
    }
    counts = IntArray(raws.size)
    for (v in grid) if (v >= 0) counts[v]++

    val ecoW = FloatArray(GW * GH)
    val popW = FloatArray(GW * GH)
    for (i in grid.indices) {
        val v = grid[i]
        if (v >= 0) {
            ecoW[i] = (raws[v].gdp / counts[v]).toFloat()
            popW[i] = (raws[v].pop / 1_000_000.0 / counts[v]).toFloat()
        }
    }

    val nations = raws.mapIndexed { i, r ->
        val color = AColor.HSVToColor(
            floatArrayOf((i * 137.508f) % 360f, 0.40f + (i % 3) * 0.08f, 0.72f + (i % 4) * 0.06f)
        )
        Nation(i, r.name, r.code, color, r.pop / 1_000_000.0, r.gdp, 0.4 + Random(i).nextDouble() * 1.4)
    }
    val engine = GameEngine(nations, grid, grid.copyOf(), ecoW, popW)
    engine.presetAlliances()
    return engine
}
